clear all
close all
clc
% image=imread('lena.jpg');
image=imread('in1.jpg');
height = size(image,1);
width = size(image,2);

lowThresh = 10; % in percentage of the maximum of the gradient magnitude
highThresh = 40; % in percentage of the maximum of the gradient magnitude
sigmaSmoothing = 2;

%% 1. convert image in double, grayscale


%% 2. smoothing using a filter
smoothedImg = zeros(height,width);

%% 3. compute gradient magnitude and angle
gradientModule = zeros(height,width);
gradientAngle = zeros(height,width);


figure, subplot(1,2,1), imagesc(gradientModule), title('module')
subplot(1,2,2), imagesc(gradientAngle), title ('angle')

%% 4.non maxima suppression
maximaImg = zeros(height,width);


%% 5. hysteresis thresholding
edgeImage = HysteresisThresholding(maximaImg, lowThresh, highThresh);

%% 6. the end =)
figure, subplot(1,2,1), imshow(image), title('original image')
subplot(1,2,2), imshow(edgeImage), title ('Canny edge image')

