function show_lines(I,accum)
%SHOW_LINES Summary of this function goes here
%   Detailed explanation goes here

error('Error: Show Lines: Comment this line in the code and implement you code here');

end

