function accum_array = LinearHoughAccum(edge_im)

% input:    edge image that can be acquired with the MATLAB function 'edge'
% output:   accumulation array, where maximums corresponds to the lines in the image

error('Error: Hough Transform: Comment this line in the code and implement you code here');

end

