function [FilteredImage] = FilterRegions( OrigImage, BinaryForegroundMap, ...
                                          SharpeningAlpha, SmoothingSigma  )
%
% Inputs: 
% 
% OrigImage: RGB or grayscale input image to be filtered.
%
% BinaryForegroundMap: Binary map of the foreground region(s). The type 
% (class) of the input image must be logical.
%
% SharpeningAlpha: The parameter of the sharpening filter.
% 
% SmoothingSigma: Standard deviation of the gaussian filter.
%
% Outputs: 
%
% FilteredImage:  2D filtered image that has the same type and dimension 
% as the original one.
%

Error('Implement you filtering function');

end